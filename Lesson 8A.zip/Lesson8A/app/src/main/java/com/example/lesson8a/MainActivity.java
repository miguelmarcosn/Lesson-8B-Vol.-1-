package com.example.lesson8a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Integer a = R.id.team_a_score_text_view;
        Integer b = R.id.team_b_score_text_view;

        ImageButton team_a_button_plus = findViewById(R.id.plus_button1);
        ImageButton team_b_button_plus = findViewById(R.id.plus_button2);
        ImageButton team_a_button_minus = findViewById(R.id.minus_button1);
        ImageButton team_b_button_minus = findViewById(R.id.minus_button2);

        team_a_button_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increaseScore(team_a_button_plus);
            }
        });
        team_b_button_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               increaseScore(team_b_button_plus);
            }
        });
        team_a_button_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decreaseScore(team_a_button_minus);
            }
        });
        team_b_button_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decreaseScore(team_b_button_minus);
            }
        });


    }
    protected void increaseScore(ImageButton button) {
        TextView team_a_score = findViewById(R.id.team_a_score_text_view);
        TextView team_b_score = findViewById(R.id.team_b_score_text_view);


        if (button.getId() == R.id.plus_button1) {
            String currentValueA = team_a_score.getText().toString();
            int currentValueIntA = Integer.parseInt(currentValueA);
            int newValueIntA = currentValueIntA + 1;
            String newValueA = Integer.toString(newValueIntA);
            team_a_score.setText(newValueA);
        }

        if (button.getId() == R.id.plus_button2) {
            String currentValueB = team_b_score.getText().toString();
            int currentValueIntB = Integer.parseInt(currentValueB);
            int newValueIntB = currentValueIntB + 1;
            String newValueB = Integer.toString(newValueIntB);
            team_b_score.setText(newValueB);
        }
    }
    protected void decreaseScore(ImageButton button) {
        TextView team_a_score = findViewById(R.id.team_a_score_text_view);
        TextView team_b_score = findViewById(R.id.team_b_score_text_view);


        if (button.getId() == R.id.minus_button1) {
            String currentValueA = team_a_score.getText().toString();
            int currentValueIntA = Integer.parseInt(currentValueA);
            int newValueIntA = currentValueIntA - 1;
            String newValueA = Integer.toString(newValueIntA);
            team_a_score.setText(newValueA);
        }


        if (button.getId() == R.id.minus_button2) {
            String currentValueB = team_b_score.getText().toString();
            int currentValueIntB = Integer.parseInt(currentValueB);
            int newValueIntB = currentValueIntB - 1;
            String newValueB = Integer.toString(newValueIntB);
            team_b_score.setText(newValueB);
        }
    }
}